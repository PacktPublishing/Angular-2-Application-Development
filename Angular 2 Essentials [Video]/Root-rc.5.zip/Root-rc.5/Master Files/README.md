## Important Notes!

Don't forget to run `npm install` in each directory before you attempt to follow along with the example or run the final version of the code in the "end" directory.

Also, shut down any instance of Gulp you may have running in a previous directory and re-run it in this directory.


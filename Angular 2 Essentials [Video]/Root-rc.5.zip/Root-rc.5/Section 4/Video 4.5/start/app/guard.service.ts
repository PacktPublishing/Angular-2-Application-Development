import { Injectable } from '@angular/core';
import { CanActivate, CanDeactivate } from '@angular/router';
